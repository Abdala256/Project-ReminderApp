package com.example.abdala.rbank;

import android.os.Bundle;

/**
 * Created by abdala on 18/04/2018.
 */

public class CreateReminderActivity extends MainActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reminder_create);
    }
}
